// Variáveis para a animação e o jogo
let campoX, cidadeX; // Posição de onde o campo e a cidade começam
let caminhaoX, caminhaoY; // Posição do caminhão
let caminhaoVelocidade = 5; // Velocidade de movimento do caminhão

let particulas = []; // Array para armazenar partículas de celebração
let recursos = []; // Array para armazenar recursos coletáveis

let score = 0; // Pontuação do jogador
let gameState = 'start'; // Estados: 'start', 'playing', 'end'

function setup() {
  createCanvas(800, 500); // Define o tamanho da tela
  campoX = width * 0.25;
  cidadeX = width * 0.75;
  resetGame(); // Inicializa o jogo
  frameRate(30);
}

function resetGame() {
  caminhaoX = -150; // Caminhão começa fora da tela, à esquerda
  // Posição Y inicial do caminhão, centralizado na rua
  caminhaoY = height * 0.6 + 40; 
  score = 0;
  recursos = [];
  particulas = [];
  // Gera alguns recursos iniciais
  for (let i = 0; i < 5; i++) {
    recursos.push(new Recurso(random(width * 0.2 + 50, width * 0.8 - 50), random(height * 0.6 + 10, height * 0.6 + 130)));
  }
}

function draw() {
  background(240); // Cor de fundo suave

  // --- Desenha o cenário (Campo e Cidade) ---
  desenhaCenario();

  // --- Desenha a Conexão (Estrada no centro, agora maior!) ---
  desenhaEstrada();

  // --- Lógica do Jogo ---
  if (gameState === 'start') {
    displayStartScreen();
  } else if (gameState === 'playing') {
    gameLogic();
    displayScore();
  } else if (gameState === 'end') {
    displayEndScreen();
  }

  // --- Desenha e atualiza as partículas de celebração ---
  for (let i = particulas.length - 1; i >= 0; i--) {
    particulas[i].update();
    particulas[i].display();
    if (particulas[i].isFinished()) {
      particulas.splice(i, 1);
    }
  }
}

// --- Funções de Desenho ---
function desenhaCenario() {
  noStroke();
  // Campo
  fill(139, 195, 74);
  rect(0, height * 0.6, width / 2, height * 0.4);
  fill(255, 204, 0);
  ellipse(width * 0.15, height * 0.2, 80, 80);
  fill(0, 150, 0);
  rect(width * 0.1, height * 0.55, 10, 30);
  rect(width * 0.2, height * 0.53, 10, 40);
  rect(width * 0.3, height * 0.57, 10, 25);
  fill(160, 82, 45);
  rect(width * 0.35, height * 0.45, 80, 80);
  fill(180, 90, 50);
  triangle(width * 0.35, height * 0.45,
           width * 0.35 + 40, height * 0.35,
           width * 0.35 + 80, height * 0.45);
  fill(200, 200, 200);
  rect(width * 0.38, height * 0.49, 20, 30);

  // Cidade
  fill(150, 150, 150);
  rect(width / 2, height * 0.6, width / 2, height * 0.4);
  fill(100, 100, 100);
  rect(width * 0.55, height * 0.3, 70, 200);
  rect(width * 0.65, height * 0.4, 60, 150);
  rect(width * 0.75, height * 0.2, 90, 250);
  rect(width * 0.88, height * 0.35, 50, 170);
  fill(255, 255, 100);
  rect(width * 0.56, height * 0.32, 10, 10);
  rect(width * 0.56, height * 0.35, 10, 10);
  fill(50, 50, 150);
  rect(width * 0.56, height * 0.38, 10, 10);
  rect(width * 0.76, height * 0.22, 15, 15);
  fill(255, 255, 100);
  rect(width * 0.76, height * 0.25, 15, 15);
}

function desenhaEstrada() {
  fill(80, 80, 80);
  // Estrada gigante
  rect(width * 0.2, height * 0.6, width * 0.6, 150); 
  stroke(255, 255, 0);
  strokeWeight(7);
  for (let i = 0; i < width * 0.6; i += 40) {
    line(width * 0.2 + i, height * 0.6 + 75, width * 0.2 + i + 20, height * 0.6 + 75);
  }
  noStroke();
}

function desenhaCaminhao(x, y) {
  fill(180, 50, 50);
  rect(x, y, 100, 50);
  fill(70);
  rect(x + 95, y + 20, 10, 10);
  fill(100, 100, 100);
  rect(x + 105, y - 10, 50, 60);
  fill(150, 200, 255);
  rect(x + 110, y, 40, 30);
  fill(50);
  ellipse(x + 25, y + 50, 30, 30);
  ellipse(x + 75, y + 50, 30, 30);
  ellipse(x + 125, y + 50, 30, 30);
}

// --- Lógica do Jogo ---
function gameLogic() {
  // Movimento do caminhão com as setas do teclado
  if (keyIsDown(LEFT_ARROW)) {
    caminhaoX -= caminhaoVelocidade;
  }
  if (keyIsDown(RIGHT_ARROW)) {
    caminhaoX += caminhaoVelocidade;
  }
  if (keyIsDown(UP_ARROW)) { // Nova lógica para cima
    caminhaoY -= caminhaoVelocidade;
  }
  if (keyIsDown(DOWN_ARROW)) { // Nova lógica para baixo
    caminhaoY += caminhaoVelocidade;
  }

  // Limita o caminhão dentro dos limites da estrada
  // Largura da estrada: width * 0.6 (de width * 0.2 a width * 0.8)
  // Altura da estrada: 150 (de height * 0.6 a height * 0.6 + 150)
  const caminhaoLargura = 155; // Largura aproximada do caminhão desenhado
  const caminhaoAltura = 60; // Altura aproximada do caminhão desenhado

  caminhaoX = constrain(caminhaoX, width * 0.2, width * 0.8 - caminhaoLargura);
  caminhaoY = constrain(caminhaoY, height * 0.6, height * 0.6 + 150 - caminhaoAltura);


  // Gera novos recursos periodicamente
  if (frameCount % 60 === 0) { // A cada 2 segundos
    // Recursos aparecem aleatoriamente DENTRO da área da estrada
    recursos.push(new Recurso(random(width * 0.2 + 50, width * 0.8 - 50), random(height * 0.6 + 10, height * 0.6 + 130)));
  }

  // Atualiza e desenha recursos, verifica colisão
  for (let i = recursos.length - 1; i >= 0; i--) {
    recursos[i].update();
    recursos[i].display();

    // Verifica colisão entre caminhão e recurso (ajustado para o novo tamanho do caminhão)
    // Calcula a sobreposição dos retângulos do caminhão e do recurso
    if (caminhaoX < recursos[i].x + recursos[i].tamanho &&
        caminhaoX + caminhaoLargura > recursos[i].x &&
        caminhaoY < recursos[i].y + recursos[i].tamanho &&
        caminhaoY + caminhaoAltura > recursos[i].y) {
      
      score += 10; // Aumenta a pontuação
      for (let j = 0; j < 10; j++) { // Gera partículas de celebração
        particulas.push(new Particula(recursos[i].x, recursos[i].y));
      }
      recursos.splice(i, 1); // Remove o recurso coletado
    } else if (recursos[i].isOffscreen()) {
      recursos.splice(i, 1); // Remove recursos que saíram da tela
    }
  }

  // Desenha o caminhão
  desenhaCaminhao(caminhaoX, caminhaoY);

  // Mensagem de Celebração - ajustada para o contexto do jogo
  fill(50);
  textSize(32);
  textAlign(CENTER);
  text("Conectando Campo e Cidade!", width / 2, 50);

  // Exemplo de condição para o fim do jogo (se o score atingir um valor, por exemplo)
  if (score >= 100) { // Se coletar 100 pontos, o jogo termina
    gameState = 'end';
  }
}

// --- Telas do Jogo ---
function displayStartScreen() {
  fill(0, 0, 0, 200); // Fundo escuro semi-transparente
  rect(0, 0, width, height);
  fill(255);
  textSize(40);
  textAlign(CENTER, CENTER);
  text("Fluxo da Conexão", width / 2, height / 2 - 50);
  textSize(24);
  text("Colete os recursos!\nUse as SETAS do teclado para mover o caminhão.", width / 2, height / 2 + 20);
  textSize(28);
  text("Pressione ESPAÇO para começar", width / 2, height / 2 + 100);
}

function displayEndScreen() {
  fill(0, 0, 0, 200); // Fundo escuro semi-transparente
  rect(0, 0, width, height);
  fill(255);
  textSize(40);
  textAlign(CENTER, CENTER);
  text("Fim de Jogo!", width / 2, height / 2 - 50);
  textSize(32);
  text("Sua Pontuação: " + score, width / 2, height / 2);
  textSize(24);
  text("Pressione R para jogar novamente", width / 2, height / 2 + 80);
}

function displayScore() {
  fill(0);
  textSize(24);
  textAlign(LEFT, TOP);
  text("Pontos: " + score, 20, 20);
}

// --- Interação do Teclado ---
function keyPressed() {
  if (gameState === 'start' && key === ' ') { // Espaço para iniciar
    gameState = 'playing';
    resetGame();
  } else if (gameState === 'end' && (key === 'r' || key === 'R')) { // R para reiniciar
    gameState = 'playing';
    resetGame();
  }
}

// --- Classes do Jogo ---
class Particula {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.vx = random(-2, 2);
    this.vy = random(-5, -1);
    this.alpha = 255;
    this.cor = color(random(200, 255), random(100, 200), random(0, 100), this.alpha);
    this.tamanho = random(5, 15);
  }

  update() {
    this.x += this.vx;
    this.y += this.vy;
    this.alpha -= 5;
    this.vy += 0.1;
  }

  display() {
    noStroke();
    this.cor.setAlpha(this.alpha);
    fill(this.cor);
    ellipse(this.x, this.y, this.tamanho, this.tamanho);
  }

  isFinished() {
    return this.alpha < 0;
  }
}

class Recurso {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.tamanho = 30;
    this.cor = color(random(100, 255), random(100, 255), 0); // Cores de recursos (verdes/amarelos)
    this.velocidade = random(1, 3); // Recursos se movem lentamente para a esquerda
  }

  update() {
    this.x -= this.velocidade; // Move o recurso para a esquerda
  }

  display() {
    fill(this.cor);
    noStroke();
    // Desenha um "saco de grãos" simples
    rect(this.x, this.y, this.tamanho, this.tamanho);
    fill(255); // Detalhe branco
    ellipse(this.x + this.tamanho / 2, this.y + 5, this.tamanho * 0.6);
  }

  isOffscreen() {
    return this.x < -this.tamanho; // Verifica se o recurso saiu da tela
  }
}